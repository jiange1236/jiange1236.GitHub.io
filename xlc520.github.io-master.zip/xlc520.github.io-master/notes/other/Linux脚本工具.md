---
author: xlc520
title: Linux脚本工具
description: Linux脚本工具
date: 2022-01-21
category: other
tag: other
article: true
timeline: true
icon: 
password: 
---
# Linux脚本工具

## EdNovas 的 Toolbox 工具箱

 **脚本地址**

https://github.com/wdm1732418365/vpstoolbox

最新版：

```shell
CODE
wget -N https://raw.githubusercontent.com/wdm1732418365/vpstoolbox/main/ednovastool.sh && chmod +x ednovastool.sh && ./ednovastool.sh
```



