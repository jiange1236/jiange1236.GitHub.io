---
author: xlc520
title: win10快捷键
description: win10快捷键
date: 2022-02-07
category: other
tag: other
article: true
timeline: true
icon: 
password: 
---

# win10快捷键

### 1.win10 自定义

Win 10 下快捷方式设置了快捷键一直无法呼出。

在目录：

C:\Users\xxxxxx\AppData\Roaming\Microsoft\Windows\Start Menu\Programs

将要运行的程序的快捷方式放在这里，在快捷方式上-->右键-->属性增加快捷键即可呼出应用。



### 2.WinhotKey

*WinhotKey*是一款专业的全局快捷键设置软件,可以通过设置热键来实现相应的动作,包括打开文件或文件夹、调用Windows各种功能、执行相应动作等

