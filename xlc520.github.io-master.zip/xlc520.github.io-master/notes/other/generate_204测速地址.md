---
author: xlc520
title: generate_204 测速地址
description: generate_204 测速地址
date: 2022-04-02
category: other
tag: other
article: true
timeline: true
icon: others
password: 
---

# generate_204 测速地址



http://www.gstatic.com/generate_204

http://connect.rom.miui.com/generate_204

http://www.google.com/generate_204

http://cp.cloudflare.com/generate_204

http://www.qualcomm.cn/generate_204

