---
author: xlc520
title: 免费VPS
description: 免费VPS
date: 2022-01-26
category: other
tag: other
article: true
timeline: true
icon: 
password: 
---
# 免费VPS

## Oracle Cloud 甲骨文云：

永久免费两个 1h1g 的小鸡

十分适合建站用

地区极力推荐韩国春川、日本东京、大版、美国圣何塞、凤凰城，有的 ip 段解锁奈飞

硬盘空间默认 45G，可以用作离线下载也不错

网络 48~60M 每月 10T

https://www.oracle.com/cloud/

不要挂梯子，一张自己的双币信用卡过验证即可

参考教程：[正确永久白嫖 Oracle Cloud](https://ednovas.xyz/2021/01/14/oraclecloud/)

### ARM

新上永久免费 arm 机

配置最高可达 4H24G

但是注意总共（amd 和 arm 加起来）的磁盘空间不能超过 200G，ipv4 数量不能超过 4 个

所以一般最大上限是开两个 amd，两个 2h12g 的 arm，全部用默认分配的磁盘空间（或者 4 个 1h6g 的 arm 机）

## GCP 谷歌云

现在是免费薅 3 个月的试用，不升级付费不会额外扣款，300 美刀的免费试用

G 口，推荐使用香港地区

https://cloud.google.com/

必须要一张实体信用卡过验证，所以十分难薅，不过只要是自己的即可轻松过

## AWS 亚马逊云

免费一年，虚拟卡可过，套路较多，特别容易产生扣费，建议多谷歌一下查看相关教程再薅

每月 15G 流量，所以一般是月抛，自己用不合算

https://aws.amazon.com/

## AZURE 微软云

免费一年，注意别开错了机子，不然也容易产生扣费，建议谷歌一下相关教程再薅

免费 linux*1 & windows*1 动态 ip，b1s 机型，64G 硬盘存储是免费的

自己过信用卡验证是 200 刀首月免费，每月 15G，超出即扣费

学生 100 刀不用信用卡验证，需要过手机号验证，建议使用专业接码网站和学生邮箱账户，基本也是月抛

https://azure.microsoft.com/en-us/

## CIVO

免费英国 VPS 一个月，原生 IP 解锁奈飞。需要信用卡验证

[https://www.civo.com](https://www.civo.com/)

## Linuxone

免费 120 天，邮箱注册即可，不需要信用卡验证。注册理由写明是学生等研究用途

容易触发风控，目前已知的封号原因：

1. 脚本触发了 v2ray、trojan 等关键词
2. 频繁删机重开
3. 大流量占用

https://linuxone.cloud.marist.edu/#/login

## Hax VPS

纯 ipv6，面板可以很方便的添加 ipv4 配置 1H512M

注册仅需一个 tg 账号，不用信用卡

理论永久免费，需要每周手动续订一下

参考 [这里](https://ednovas.xyz/2021/10/04/haxvps/)

## 华为云

需要信用卡

免费试用 1500 小时

https://activity.huaweicloud.com/intl/zh-cn/free_packages/

## 阿里云

需要信用卡

免费试用 12 个月 1H1G 或者 3 个月 2H2G

https://www.alibabacloud.com/zh/campaign/free-trial

## Vultr

需要信用卡

注册送 100 美元，一个月时限

https://www.vultr.com/?ref=8971645-8H

## Linode

注册免费送两个月有效的 100 刀，需要信用卡，配置 1H1G 等

https://www.linode.com/lp/brand-free-credit-short/

## Ditital Ocean

需要信用卡或者 paypal

注册送 100 美元

https://www.digitalocean.com/?refcode=492076b14fb2&utm_campaign=Referral_Invite&utm_medium=Referral_Program&utm_source=CopyPaste

有学生邮箱的建议开通 GitHub 学生包然后用 DO 的激活码来激活免费的 100 刀，需要过信用卡验证

GitHub 学生包：https://education.github.com/pack

这个包里还有包括域名在内等其他很多免费学生专属福利

## Euserv

德国纯 ipv6 小鸡，不用信用卡，审核时间较久

1H1G 配置一般，邻居容易搞事

https://euserv.com/

参考教程 [白嫖 Euserv VPS（理论永久）](https://ednovas.xyz/2021/01/16/euserv/)

he tunnel 添加 ipv4（/2021/04/15/hetunnel/）

warp 添加 ipv4/ipv6（/2021/04/15/warpipv6/）

## Kamatera

https://www.kamatera.com/express/compute/

绑卡扣除 2 美刀验证，支持 +86 手机和 googlevoice 验证

任选配置，免费一个月，300 刀，试用代码 `1MONTH300`

最高配置可选 40 核专用 CPU，512G 内存，4TB 固态，5T 流量（香港 1T），1G 带宽

CPU 类型 B 是通用型，性能一般。D 是专用型，性能最强。T 是突发型，性能较强。A 是可用型，性能最弱。

可选美国（纽约、达拉斯、圣塔克拉拉）、加拿大（多伦多）、欧洲（阿姆斯特丹、法兰克福、伦敦）、以色列（皮塔赫。提克瓦、罗什。海因 1/2、特拉维夫、耶路撒冷）、中国（香港）等地区

香港并非三网直连，速度很慢，美国地区是很干净的原生 ip

## Yandex Cloud

Yandex 云新注册用户赠送价值 4000 卢布 (大概 350 人民币), 有效期 60 天的免费试用。其中 1000 卢布用于云主机，3000 用于其他云计算服务

https://concole.cloud.yandex.ru/

需要绑定银行卡，必须支持 3D 安全验证。可以使用 yandex.money 虚拟卡，国家建议选俄罗斯

yandex.money: https://yoomoney.ru/

yandex.money 哪国手机号都可接码，虚拟身份认证一下即可

## Evolution Host

需要有一个有流利的博客才可申请，然后博客首页放上他们的广告即可白嫖

https://evolution-host.com/free-vps.php