---
author: xlc520
title: 开源后台管理项目
description: 开源后台管理项目
date: 2022-01-21
category: Code
tag: Code
article: true
dateline: true
icon: 
password: 
---
# 开源后台管理项目



1、vue-Element-Admin

Github Star 数 45100， Github 地址：

[https://github.com/PanJiaChen/vue-element-admin](https://github.com/PanJiaChen/vue-element-admin)

[https://panjiachen.github.io/vue-element-admin-site/zh/](https://panjiachen.github.io/vue-element-admin-site/zh/)

一个基于 vue2.0 和 Eelement 的控制面板 UI 框架。



2、AdminLTE

Github Star 数 32000 ， Github 地址：

[https://github.com/almasaeed2010/AdminLTE](https://github.com/almasaeed2010/AdminLTE)

[https://adminlte.io/](https://adminlte.io/)



3、ant-design-pro

Github Star 数 22600，Github 地址：

[https://github.com/ant-design/ant-design-pro](https://github.com/ant-design/ant-design-pro)

开箱即用的中台前端/设计解决方案



4、tabler

Github Star 数 20000， Github 地址：

[https://github.com/tabler/tabler](https://github.com/tabler/tabler)

构建在 BootStrap 4 之上的免费的 HTML 控制面板框架



5、ng2-admin

Github Star 数 19000， Github 地址：

[https://github.com/akveo/ngx-admin](https://github.com/akveo/ngx-admin)

基于 Angular 2, Bootstrap 4 和 Webpack 的后台管理面板框架。



6、Gentelella

Github Star 数 18300， Github 地址：

[https://github.com/puikinsh/gentelella](https://github.com/puikinsh/gentelella)

一个基于 Bootstarp 的免费的后台控制面板。



7、iview-admin

Github Star 数 13700，Github 地址：

[https://github.com/iview/iview-admin](https://github.com/iview/iview-admin)

基于 iView 的 Vue 2.0 控制面板。



8、blur-admin

Github Star 数 10600，Github 地址：

[https://github.com/akveo/blur-admin](https://github.com/akveo/blur-admin)

基于 Angular 和 Bootstrap 的后台管理面板框架。



9、vue-admin

Github Star 数 9400，Github 地址：

[https://github.com/vue-bulma/vue-admin](https://github.com/vue-bulma/vue-admin)

基于 Vue 和 Bulma 的控制面板。



10、material-dashboard

Github Star 数 8600，Github 地址：

[https://github.com/creativetimofficial/material-dashboard](https://github.com/creativetimofficial/material-dashboard)

基于 Bootstrap 4 和 Material 风格的控制面板。



11、pearadmin

[http://www.pearadmin.com](http://www.pearadmin.com)

