---
author: xlc520
title: Study
description: Study
date: 2022-01-01
category: Study
tag: Study
article: true
dateline: true
icon: note
password: 
---


<p align="center"> 
  <img src="https://metrics.lecoq.io/xlc520?template=classic&isocalendar=1&languages=1&people=1&activity=1&achievements=1&lines=1&repositories=1&notable=1&introduction=1&pagespeed=1&repositories=100&repositories.batch=100&repositories.forks=false&repositories.affiliations=owner&isocalendar.duration=full-year&languages.limit=8&languages.threshold=0%25&languages.colors=github&languages.sections=most-used&languages.indepth=false&languages.analysis.timeout=15&languages.categories=markup%2C%20programming&languages.recent.categories=markup%2C%20programming&languages.recent.load=300&languages.recent.days=14&people.limit=24&people.identicons=false&people.identicons.hide=false&people.size=28&people.types=followers%2C%20following&people.shuffle=false&activity.limit=5&activity.load=300&activity.days=14&activity.visibility=all&activity.timestamps=false&activity.filter=all&achievements.threshold=C&achievements.secrets=true&achievements.display=detailed&achievements.limit=0&notable.from=organization&notable.repositories=false&notable.indepth=false&notable.types=commit&repositories.featured=%20xlc520%2Fxlc520.github.io&introduction.title=true&pagespeed.url=xlc520.github.io&pagespeed.detailed=false&pagespeed.screenshot=false&config.timezone=Asia%2FShanghai" /> 
</p>
<p align="center"> 
  您是第  <img src="https://profile-counter.glitch.me/xlc520/count.svg" />  位访问者
</p>